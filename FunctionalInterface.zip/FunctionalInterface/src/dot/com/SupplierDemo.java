package dot.com;

import java.util.Arrays;
import java.util.List;
import java.util.function.Supplier;

public class SupplierDemo {

	public static void main(String[] args) {
		
		Supplier<Integer> s = () -> 25;
//		System.out.println(s.get());
		
		List<Integer> list = Arrays.asList();
		
		System.out.println(list.stream().findAny().orElseGet(s));
	}
}

// By default orElseGet call Supplier interface