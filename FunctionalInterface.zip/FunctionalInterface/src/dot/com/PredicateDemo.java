package dot.com;

import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;

public class PredicateDemo {

	public static void main(String[] args) {
		
		Predicate<Integer> p = a -> a % 3 == 0;
//		System.out.println(p.test(55));
		
		List<Integer> list = Arrays.asList(40,76,50,99);
		
		list.stream().filter(a -> a % 2 == 0).forEach(a -> System.out.println(a));
	}
}

// By default filter call Predicate interface