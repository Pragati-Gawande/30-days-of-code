package dot.com;

import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;

public class ConsumerDemo {

	public static void main(String[] args) {
		
		Consumer<Integer> c = a -> System.out.println(a);
		c.accept(10);
		
		List<Integer> list = Arrays.asList(40,70,50,90);
		
		list.stream().forEach(a -> System.out.println(a));
	}
}

// By default forEach call Consumer interface