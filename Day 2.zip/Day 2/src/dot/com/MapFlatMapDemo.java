package dot.com;

import java.util.List;
import java.util.stream.Collectors;

public class MapFlatMapDemo {
	public static void main(String[] args) {
		List<Customer> customers = TiraDatabase.getCustomers();
		
		List<String> emails = customers.stream().map(c -> c.getEmail()).collect(Collectors.toList());
		System.out.println(emails);
		
		List<List<String>> phone = customers.stream().map(c -> c.getPhoneNumbers()).collect(Collectors.toList());
		System.out.println(phone);
		
		List<String> phones = customers.stream().flatMap(c -> c.getPhoneNumbers().stream()).collect(Collectors.toList());
		System.out.println(phones);
	}

}


//List<Customers> converting to List<String> 
//data transformation