package dot.com;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class TiraDatabase {

	public static List<Customer> getCustomers() {
		return Stream.of(
				new Customer(11, "Pragati", "progress@gmail.com", Arrays.asList("998875","77678")),
				new Customer(12, "Pragati", "progress@gmail.com", Arrays.asList("998875","77678")),
				new Customer(17, "Pragati", "progress@gmail.com", Arrays.asList("998875","77678")),
				new Customer(15, "Pragati", "progress@gmail.com", Arrays.asList("998875","77678"))

	).collect(Collectors.toList());
	}
}
