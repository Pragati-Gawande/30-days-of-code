package dot.com;

import java.util.Optional;

public class OptionalDemo {
	public static void main(String[] args) {
		
		Customer c1 = new Customer(1, "Trisha");
		Customer c2 = new Customer(2, "Shreya");
		
		System.out.println(c1);
//		System.out.println(c2.getName().toLowerCase());
		
		Optional<Object> o1 = Optional.empty();
		System.out.println(o1);
		
//		Optional<Object> o2 = Optional.of(c2.getName());
//		System.out.println(o2);
		
		Optional<String> o3 = Optional.ofNullable(c2.getName());
		System.out.println(o3);
		
//		System.out.println(o3.orElseThrow(() -> new IllegalAccessError("Name is empty")));
		
		System.out.println(o3.map(String::toUpperCase).orElseGet(() -> "default name"));
		
	}

}
