package dot.com;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.stream.IntStream;

public class EvenOddESandCF {

	public static void main(String[] args) {
		
		ExecutorService executorService = Executors.newFixedThreadPool(2);
		
		IntStream.rangeClosed(1, 10)
		.forEach(num -> {
			CompletableFuture<Integer> oddCompletableFuture = CompletableFuture.completedFuture(num)
					.thenApplyAsync(a -> {
						if(a%2 != 0) { 
							System.out.println("Thread Name" + Thread.currentThread().getName() + " value: " + a);
						}
						return num;
					}, executorService);
			oddCompletableFuture.join();
			
			CompletableFuture<Integer> evenCompletableFuture = CompletableFuture.completedFuture(num)
					.thenApplyAsync(a -> {
						if(a%2 == 0) { 
							System.out.println("Thread Name" + Thread.currentThread().getName() + " value: " + a);
						}
						return num;
					}, executorService);
			evenCompletableFuture.join();
			});
		executorService.shutdown();
	}
}

// Print Even and Odd number using 2 thread
// USing Java8 Executor service and completeableFuture