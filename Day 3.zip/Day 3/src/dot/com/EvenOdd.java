package dot.com;

import java.util.concurrent.CompletableFuture;
import java.util.function.IntPredicate;
import java.util.stream.IntStream;


public class EvenOdd {

	private static Object object = new Object();
	
	public static void main(String[] args) throws InterruptedException {
		CompletableFuture.runAsync(() -> EvenOdd.printResult(oddCondition));
		CompletableFuture.runAsync(() -> EvenOdd.printResult(evenCondition));
		Thread.sleep(1000);
	}
	
	private static IntPredicate evenCondition = i -> i%2 == 0;
	private static IntPredicate oddCondition = i -> i%2 != 0;

	
	public static void printResult(IntPredicate condition) {
		IntStream.rangeClosed(1, 10)
		.filter(condition)
		.forEach(EvenOdd :: execute);
	}

	public static void execute(int i) {
		synchronized (object) {
			try {
				System.out.println("Thread Name " + Thread.currentThread().getName() + " : " + i);
				object.notify();

				object.wait();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}
