package dot.com.streams;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import dot.com.collections.Employee;

public class StreamFeatures {

	public static void main(String[] args) {

		// Stream::ofNullable
		List<String> list = Arrays.asList("Kimti", "Shreya", "Tina", null);
		List<String> filterNullName = list.stream().flatMap(Stream::ofNullable).collect(Collectors.toList());

		System.out.println(filterNullName);

		// Stream::iterate

		Stream.iterate(1, n -> n+9).limit(5)
		.forEach(System.out::println);

		//  Collectors.collectingAndThen || calculate average salary of employee and round it to nearest integer

		List<Employee> employees = Arrays.asList(
				new Employee("Trisha", 1500000),
				new Employee("Rits", 1000000), 
				new Employee("Swift", 1500000)
				);

		Long avgSal = employees.stream().mapToDouble(Employee::getSalary)
				.boxed()
				.collect(Collectors.collectingAndThen(
						Collectors.averagingDouble(Double::doubleValue),
						Math::round)
						);

		System.out.println(avgSal);

	  //  calculate average salary of employee 
		double avg = employees.stream().mapToDouble(Employee::getSalary)
				.boxed()
				.collect(
						Collectors.averagingDouble(Double::doubleValue)
						);

		System.out.println(avg);
		
	 // takeWhile and dropWhile
		List<Integer> nos = List.of(1,2,3,4,5,6,7,8,9,4);
		List<String> str = List.of("tiah", "ahjh");
		List<String> str1 = List.of("tiah", "ahjh");
		nos = nos.stream().takeWhile(a -> a < 3).collect(Collectors.toList());
		str = str.stream().dropWhile(a -> a.equalsIgnoreCase("tiah")).collect(Collectors.toList());
		str1 = str1.stream().takeWhile(a -> a.equalsIgnoreCase("tiah")).collect(Collectors.toList());

		System.out.println(nos +" " +str + " "+str1);
		
	// Collectors.teeing

	}
}

// Stream::ofNullable
// Stream.iterate
// Collectors.collectingAndThen
// takeWhile and dropWhile