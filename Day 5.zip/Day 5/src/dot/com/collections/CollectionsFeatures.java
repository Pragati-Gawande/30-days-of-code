package dot.com.collections;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class CollectionsFeatures {

	public static void main(String[] args) {
		
		// Collections.nCopies
		
		List<String> list = Collections.nCopies(2, "Testing");
		System.out.println(list);
		
		try {
			list.set(0, "Test");
		} catch(UnsupportedOperationException e) {
			System.out.println("Exception catched");
		}
		
		// Collections.frequency()
		
		List<String> list1 = Arrays.asList("aap", "dono","aap","techno");
		int freList = Collections.frequency(list1, "dono");
		System.out.println(freList);
		
		
		// To find common value between 2 list we can use disjoint method
		
		List<Integer> list2 = new ArrayList<>();
		Collections.addAll(list2, 5,6,7,7,8,9);
		
		List<Integer> list3 = new ArrayList<>();
		Collections.addAll(list3, 1,2,4,3,4,5);
		
		boolean outCommon = Collections.disjoint(list2, list3);
		
		if(outCommon) {
			System.out.println("We do not have common element in list");
		} else {
			System.out.println("We have common element in list");
		}	
		
		// Collections.rotate()
		
		List<Integer> list4 = Arrays.asList(1,2,3,4,5,6,7,8,9,10);
		System.out.println(list4);
		Collections.rotate(list4, 2);
		System.out.println(list4);
	}
}


// Collections.cCopies()
// Collections.frequency()
// Collections.disjoint()
// Collections.rotate()